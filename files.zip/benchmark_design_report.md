# AGI Cognitive Benchmark — Design Report

## Competition: Measuring Progress Toward AGI (Google DeepMind / Kaggle)

**Submission Method**: Kaggle Community Benchmarks platform (`kaggle-benchmarks` SDK with `@kbench.task` decorators)

**Models Evaluated**: Gemini 2.5 Flash/Pro, Claude Sonnet 4, Llama 3.1 70B, DeepSeek, Mistral Large (provided by Kaggle's platform — no local model loading needed)

---

## Track Overview

| Track | Items | Task Types | Human Baseline (avg) |
|-------|-------|------------|----------------------|
| attention | 320 | change_blindness, distractor_resist, needle_haystack, sustained_tracking | 0.80 |
| executive | 360 | inhibitory_control, sequential_plan, task_switching, working_memory | 0.88 |
| learning | 340 | analogy_completion, compositional, few_shot_rule, novel_concept | 0.90 |
| metacognition | 320 | confidence_calib, error_detection, know_unknowns, source_reliability | 0.80 |
| social_cognition | 380 | faux_pas, norm_violation, pragmatic_inf, tom_level1, tom_level2 | 0.86 |

---

## Task Design Principles

### 1. Beyond Recall
Every task requires the model to reason, infer, or simulate — not retrieve memorised facts. Parameterised generators ensure infinite novel variants.

### 2. LeCun-Aligned Design
Tasks specifically target the three gaps LeCun (2022) identifies:
- **Sample efficiency**: k-shot rule induction (1–16 examples)
- **Causal reasoning**: beyond correlation to intervention and counterfactual
- **Physical simulation**: spatial rotation, conservation, intuitive physics

### 3. Appropriate Assertion Types
- `exact_number`: arithmetic and counting tasks
- `regex_case_insensitive`: single-word or yes/no answers
- `llm_judge`: open-ended social cognition and metacognition tasks

### 4. Human Baselines
All baselines are sourced from published cognitive psychology literature:

- *Lake et al. 2015, Science* — `few_shot_rule` (baseline=0.92)
- *Raven 1936, SPM* — `analogy_completion` (baseline=0.85)
- *Fodor & Pylyshyn 1988* — `compositional` (baseline=0.89)
- *Carey 2009* — `novel_concept` (baseline=0.94)
- *Lichtenstein et al. 1982* — `confidence_calib` (baseline=0.74)
- *Kruger & Dunning 1999* — `know_unknowns` (baseline=0.82)
- *Stroop 1935* — `distractor_resist` (baseline=0.68)
- *Parasuraman 1984* — `sustained_tracking` (baseline=0.85)
- *Simons & Chabris 1999* — `change_blindness` (baseline=0.61)
- *Shallice 1982 TOL* — `sequential_plan` (baseline=0.93)
- *Baddeley 1986* — `working_memory` (baseline=0.8)
- *Monsell 2003* — `task_switching` (baseline=0.89)
- *Wimmer & Perner 1983* — `tom_level1` (baseline=0.87)
- *Perner & Wimmer 1985* — `tom_level2` (baseline=0.72)
- *Baron-Cohen et al. 1999* — `faux_pas` (baseline=0.84)
- *Levinson 2000* — `pragmatic_inf` (baseline=0.88)
- *Gibbs 1994* — `sarcasm` (baseline=0.87)
- *Turiel 1983* — `norm_violation` (baseline=0.95)
- *CausalProbe 2024 NeurIPS* — `causal_l1` (baseline=0.89)
- *Pearl 2009 do-calculus* — `causal_l2` (baseline=0.78)
- *Pearl 2009 counterfactual* — `causal_l3` (baseline=0.73)
- *Lake et al. 2015 1-shot* — `sample_efficiency_1` (baseline=0.91)
- *Lake et al. 2015 16-shot* — `sample_efficiency_16` (baseline=0.98)
- *McCloskey 1983* — `physical_intuition` (baseline=0.85)

---

## Assertion Strategy

- `exact_number`: 640 tasks (37.2%)
- `regex_case_insensitive`: 560 tasks (32.6%)
- `llm_judge`: 520 tasks (30.2%)

---

## Difficulty Distribution

- Difficulty 1: 67 tasks
- Difficulty 2: 206 tasks
- Difficulty 3: 822 tasks
- Difficulty 4: 470 tasks
- Difficulty 5: 155 tasks

---

## How to Submit

1. Go to https://www.kaggle.com/benchmarks/tasks/new
2. The `kaggle-benchmarks` SDK is pre-installed
3. Paste this script and call `run_kaggle_benchmark_tasks()`
4. Kaggle runs tasks against Gemini, Claude, Llama, etc.
5. Results appear on the competition leaderboard automatically
6. Submit your benchmark to the competition via the Kaggle UI
